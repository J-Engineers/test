<?php
	define('title', 'HNGI 6.0');
	define("logo", "assets/images/nigeria.png");
?>